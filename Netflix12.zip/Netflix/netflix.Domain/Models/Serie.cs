namespace netflix.Domain.Models;

public class Serie
{
    public int Id { get; set; }
    public string Titulo { get; set; } = string.Empty;
    public string Descripcion { get; set; } = string.Empty;
    public int DuracionMinutos { get; set; }
    public int Temporadas { get; set; }
    public string VideoUrl { get; set; } = string.Empty; // URL subida a Cloudinary
    public DateTime FechaLanzamiento { get; set; }
}
