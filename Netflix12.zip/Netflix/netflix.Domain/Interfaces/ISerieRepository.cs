using netflix.Domain.Models;

namespace netflix.Domain.Interfaces;

public interface ISerieRepository
{
    Task<IEnumerable<Serie>> GetAllAsync();
    Task<Serie> GetByIdAsync(int id);
    Task AddAsync(Serie serie);
    Task UpdateAsync(Serie serie);
    Task DeleteAsync(int id);
    
}