using netflix.Domain.Models;

namespace netflix.Domain.Interfaces;

public interface IPeliculaRepository
{
    Task<IEnumerable<Pelicula>> GetAllAsync();
    Task<Pelicula> GetByIdAsync(int id);
    Task AddAsync(Pelicula pelicula);
    Task UpdateAsync(Pelicula pelicula);
    Task DeleteAsync(int id);
}