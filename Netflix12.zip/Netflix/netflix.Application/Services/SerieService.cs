using netflix.Domain.Interfaces;
using netflix.Domain.Models;

namespace netflix.Application.Services;

public class SerieService
{
    private readonly ISerieRepository _repository;
    public SerieService(ISerieRepository repository)
    {
        _repository = repository;
    }

    public Task<IEnumerable<Serie>> GetAll()
    {
        return _repository.GetAllAsync();
    }

    public Task<Serie> GetById(int id)
    {
        return _repository.GetByIdAsync(id);
    }

    public Task Add(Serie serie)
    {
        return _repository.AddAsync(serie);
    }

    public Task Update(Serie serie)
    {
        return _repository.UpdateAsync(serie);
    }

    public Task Delete(int id)
    {
        return _repository.DeleteAsync(id);
    }
}