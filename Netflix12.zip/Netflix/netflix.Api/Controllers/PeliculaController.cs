using CloudinaryDotNet;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using netflix.Application.Helpers;
using netflix.Application.Requests;
using netflix.Application.Services;
using netflix.Domain.Models;

namespace netflix.Api.Controllers;

[ApiController]
[Route("api/pelicula")]
public class PeliculaController : ControllerBase
{
    private readonly PeliculaService _service;
    private readonly CloudinaryHelper _cloud;
    public PeliculaController(PeliculaService service, CloudinaryHelper cloud)
    {
        _service = service;
        _cloud = cloud;
    }

    [HttpGet]
    public async Task<ActionResult> GetAll()
    {
        var peliculas = await _service.GetAllPeliculas();
        return Ok(peliculas);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult> GetById(int id)
    {
        var pelicula = await _service.GetPeliculaById(id);
        if (pelicula == null) return NotFound();
        return Ok(pelicula);
    }

    [Authorize(Roles = "admin")]
    [HttpPost]
    public async Task<ActionResult> Create([FromForm] PeliculaRequest req)
    {
        var url = await _cloud.UploadVideoAsync(req.Video);
        var pelicula = new Pelicula
        {
            Titulo = req.Titulo,
            Descripcion = req.Descripcion,
            DuracionMinutos = req.DuracionMinutos,
            FechaLanzamiento = req.FechaLanzamiento,
            VideoUrl = url,
        };
        await _service.Add(pelicula);
        return Ok(pelicula);
    }

    [Authorize(Roles = "admin")]
    [HttpPut("{id}")]
    public async Task<ActionResult> Update(int id, [FromForm] PeliculaRequest req)
    {
        var pelicula = await _service.GetPeliculaById(id);
        if (pelicula == null) return NotFound();
        
        pelicula.Titulo = req.Titulo;
        pelicula.Descripcion = req.Descripcion;
        pelicula.DuracionMinutos = req.DuracionMinutos;
        pelicula.FechaLanzamiento = req.FechaLanzamiento;
        if (req.Video != null)
            pelicula.VideoUrl = await _cloud.UploadVideoAsync(req.Video);
        
        await _service.Update(pelicula);
        return Ok(pelicula);
    }

    [Authorize(Roles = "admin")]
    [HttpDelete("{id}")]
    public async Task<ActionResult> Delete(int id)
    {
        await _service.Remove(id);
        return Ok(new {message = "Pelicula eliminado correctamente. "});
    }
}