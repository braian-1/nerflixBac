using Microsoft.EntityFrameworkCore;
using netflix.Domain.Interfaces;
using netflix.Domain.Models;
using netflix.Infrastructure.Data;

namespace netflix.Infrastructure.Repositories;


    public class SerieRepository : ISerieRepository
    {
        private readonly AppDbContext _context;
        public SerieRepository(AppDbContext context) => _context = context;

        public async Task<IEnumerable<Serie>> GetAllAsync() => await _context.Series.ToListAsync();

        public async Task<Serie?> GetByIdAsync(int id) => await _context.Series.FindAsync(id);

        public async Task AddAsync(Serie serie)
        {
            _context.Series.Add(serie);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Serie serie)
        {
            _context.Series.Update(serie);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var s = await GetByIdAsync(id);
            if (s != null)
            {
                _context.Series.Remove(s);
                await _context.SaveChangesAsync();
            }
        }
    }
