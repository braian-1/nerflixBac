using netflix.Domain.Models;
using Microsoft.EntityFrameworkCore;

namespace netflix.Infrastructure.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<User> Users { get; set; }       // Tabla Usuarios
        public DbSet<Pelicula> Peliculas { get; set; } // Tabla Películas
        public DbSet<Serie> Series { get; set; }       // Tabla Series

    }
}