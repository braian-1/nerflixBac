namespace netflix.Domain.Enums;

public enum TipoContenido
{
    Pelicula = 1,
    Serie = 2
}