using Microsoft.AspNetCore.Http;

namespace netflix.Application.Requests
{
    public class PeliculaRequest
    {
        public string Titulo { get; set; }
        public string Descripcion { get; set; }
        public int DuracionMinutos { get; set; }
        public DateTime FechaLanzamiento { get; set; }
        public IFormFile Video { get; set; }
    }
} 