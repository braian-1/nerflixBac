using netflix.Domain.Interfaces;
using netflix.Domain.Models;

namespace netflix.Application.Services;

public class PeliculaService
{
    private readonly IPeliculaRepository _repository;
    public PeliculaService(IPeliculaRepository repository)
    {
        _repository = repository;
    }

    public async Task<IEnumerable<Pelicula>> GetAllPeliculas()
    {
        return await _repository.GetAllAsync();
    }

    public async Task<Pelicula> GetPeliculaById(int id)
    {
        return await _repository.GetByIdAsync(id);
    }

    public async Task Add(Pelicula pelicula)
    {
        await _repository.AddAsync(pelicula);
    }

    public async Task Update(Pelicula pelicula)
    {
        await _repository.UpdateAsync(pelicula);
    }

    public async Task Remove(int id)
    {
        await _repository.DeleteAsync(id);
    }
}