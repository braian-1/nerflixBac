using Microsoft.Extensions.Configuration;
using System.Net.Http;
using System.Net.Http.Headers;

namespace netflix.Application.Services
{
    public class TmdbService
    {
        private readonly HttpClient _http;

        public TmdbService(HttpClient http, IConfiguration config)
        {
            _http = http;

            _http.BaseAddress = new Uri(
                config["TMDB:BaseUrl"]!.TrimEnd('/') + "/"
            );

            _http.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue(
                    "Bearer",
                    config["TMDB:Token"]
                );
        }

        // 🔥 Películas populares (paginadas)
        public async Task<string> GetPopularMovies(int page = 1)
        {
            var res = await _http.GetAsync(
                $"movie/popular?language=es-ES&page={page}"
            );
            res.EnsureSuccessStatusCode();
            return await res.Content.ReadAsStringAsync();
        }

        // ⭐ Top Rated
        public async Task<string> GetTopRatedMovies(int page = 1)
        {
            var res = await _http.GetAsync(
                $"movie/top_rated?language=es-ES&page={page}"
            );
            res.EnsureSuccessStatusCode();
            return await res.Content.ReadAsStringAsync();
        }

        // 📺 Series populares
        public async Task<string> GetPopularSeries(int page = 1)
        {
            var res = await _http.GetAsync(
                $"tv/popular?language=es-ES&page={page}"
            );
            res.EnsureSuccessStatusCode();
            return await res.Content.ReadAsStringAsync();
        }

        // 🔍 Buscar películas
        public async Task<string> SearchMovies(string query, int page = 1)
        {
            var res = await _http.GetAsync(
                $"search/movie?query={Uri.EscapeDataString(query)}&language=es-ES&page={page}"
            );
            res.EnsureSuccessStatusCode();
            return await res.Content.ReadAsStringAsync();
        }

        // 📈 Trending
        public async Task<string> GetTrending(int page = 1)
        {
            var res = await _http.GetAsync(
                $"trending/all/week?language=es-ES&page={page}"
            );
            res.EnsureSuccessStatusCode();
            return await res.Content.ReadAsStringAsync();
        }

        // 🎬 Detalle
        public async Task<string> GetMovieDetails(int id)
        {
            var res = await _http.GetAsync(
                $"movie/{id}?language=es-ES"
            );
            res.EnsureSuccessStatusCode();
            return await res.Content.ReadAsStringAsync();
        }
        
        public async Task<string> SearchMulti(string query, int page = 1)
        {
            var res = await _http.GetAsync(
                $"search/multi?query={Uri.EscapeDataString(query)}&language=es-ES&page={page}"
            );
            res.EnsureSuccessStatusCode();
            return await res.Content.ReadAsStringAsync();
        }

    }
}
