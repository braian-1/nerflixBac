using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using netflix.Application.Helpers;
using netflix.Application.Services;
using netflix.Domain.Interfaces;
using netflix.Infrastructure.Data;
using netflix.Infrastructure.Repositories;
using login1.Infrastructure.Repositories;

var builder = WebApplication.CreateBuilder(args);

// =======================
// 🔌 Database
// =======================
var connectionString = builder.Configuration.GetConnectionString("Default");

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString))
);

// =======================
// 🌍 CORS
// =======================
builder.Services.AddCors(options =>
{
    options.AddPolicy("CorsPolicy", policy =>
    {
        policy.WithOrigins("http://localhost:5173")
            .AllowAnyMethod()
            .AllowAnyHeader();

    });
});

// =======================
// 📦 Repositories
// =======================
builder.Services.AddScoped<IUserRepositorie, UserRepositorie>();
builder.Services.AddScoped<IPeliculaRepository, PeliculaRepository>();
builder.Services.AddScoped<ISerieRepository, SerieRepository>();

// =======================
// 🧠 Services
// =======================
builder.Services.AddScoped<UserService>();
builder.Services.AddHttpClient<TmdbService>();
builder.Services.AddScoped<PeliculaService>();
builder.Services.AddScoped<SerieService>();
builder.Services.AddScoped<AuthServices>();
builder.Services.AddScoped<CloudinaryHelper>();

// =======================
// 🔐 JWT Authentication
// =======================
var jwtSettings = builder.Configuration.GetSection("Jwt");
var key = Encoding.UTF8.GetBytes(jwtSettings["key"]!);

builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,

            ValidIssuer = jwtSettings["issuer"],
            ValidAudience = jwtSettings["audience"],
            IssuerSigningKey = new SymmetricSecurityKey(key),
            ClockSkew = TimeSpan.Zero
        };
    });

// =======================
// 🧩 Controllers
// =======================
builder.Services.AddControllers();

// =======================
// 📘 Swagger + JWT 🔒
// =======================
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "Netflix API",
        Version = "v1"
    });

    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = "Ingresa el token así: Bearer {tu_token}"
    });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            Array.Empty<string>()
        }
    });
});

// =======================
// 🚀 App
// =======================
var app = builder.Build();

// =======================
// 🌍 Middleware
// =======================
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

// 👇 CORS DEBE IR AQUÍ
app.UseCors("CorsPolicy");

// 🔐 Seguridad
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
