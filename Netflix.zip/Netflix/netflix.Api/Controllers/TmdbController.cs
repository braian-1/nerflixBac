using Microsoft.AspNetCore.Mvc;
using netflix.Application.Services;

namespace netflix.Api.Controllers;

[ApiController]
[Route("api/tmdb")]
public class TmdbController : ControllerBase
{
    private readonly TmdbService _tmdb;

    public TmdbController(TmdbService tmdb)
    {
        _tmdb = tmdb;
    }

    // 🔥 Películas populares (MUCHAS)
    [HttpGet("popular")]
    public async Task<IActionResult> Popular([FromQuery] int page = 1)
    {
        var json = await _tmdb.GetPopularMovies(page);
        return Content(json, "application/json");
    }

    // ⭐ Top Rated
    [HttpGet("top")]
    public async Task<IActionResult> Top([FromQuery] int page = 1)
    {
        var json = await _tmdb.GetTopRatedMovies(page);
        return Content(json, "application/json");
    }

    // 📺 Series
    [HttpGet("series")]
    public async Task<IActionResult> Series([FromQuery] int page = 1)
    {
        var json = await _tmdb.GetPopularSeries(page);
        return Content(json, "application/json");
    }

    // 🔍 Buscar
    [HttpGet("search")]
    public async Task<IActionResult> Search(
        [FromQuery] string q,
        [FromQuery] int page = 1
    )
    {
        var result = await _tmdb.SearchMovies(q, page);
        return Content(result, "application/json");
    }

    // 📈 Trending
    [HttpGet("trending")]
    public async Task<IActionResult> Trending([FromQuery] int page = 1)
    {
        var json = await _tmdb.GetTrending(page);
        return Content(json, "application/json");
    }

    // 🎬 Detalle
    [HttpGet("movie/{id}")]
    public async Task<IActionResult> Movie(int id)
    {
        var data = await _tmdb.GetMovieDetails(id);
        return Content(data, "application/json");
    }
    
    [HttpGet("search-multi")]
    public async Task<IActionResult> SearchMulti(
        [FromQuery] string q,
        [FromQuery] int page = 1
    )
    {
        var json = await _tmdb.SearchMulti(q, page);
        return Content(json, "application/json");
    }

}