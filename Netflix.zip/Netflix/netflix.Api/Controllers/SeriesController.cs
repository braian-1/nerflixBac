using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using netflix.Application.Helpers;
using netflix.Application.Services;
using netflix.Domain.Models;

[ApiController]
[Route("api/series")]
public class SeriesController : ControllerBase
{
    private readonly SerieService _service;
    private readonly CloudinaryHelper _cloud;

    public SeriesController(SerieService service, CloudinaryHelper cloud)
    {
        _service = service;
        _cloud = cloud;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var series = await _service.GetAll();
        return Ok(series);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var serie = await _service.GetById(id);
        if (serie == null) return NotFound();
        return Ok(serie);
    }

    [Authorize(Roles = "admin")]
    [HttpPost]
    public async Task<IActionResult> Create([FromForm] SerieRequest req)
    {
        var url = await _cloud.UploadVideoAsync(req.Video);
        var serie = new Serie
        {
            Titulo = req.Titulo,
            Descripcion = req.Descripcion,
            DuracionMinutos = req.DuracionMinutos,
            Temporadas = req.Temporadas,
            FechaLanzamiento = req.FechaLanzamiento,
            VideoUrl = url
        };
        await _service.Add(serie);
        return Ok(serie);
    }

    [Authorize(Roles = "admin")]
    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, [FromForm] SerieRequest req)
    {
        var serie = await _service.GetById(id);
        if (serie == null) return NotFound();

        serie.Titulo = req.Titulo;
        serie.Descripcion = req.Descripcion;
        serie.DuracionMinutos = req.DuracionMinutos;
        serie.Temporadas = req.Temporadas;
        serie.FechaLanzamiento = req.FechaLanzamiento;

        if(req.Video != null)
            serie.VideoUrl = await _cloud.UploadVideoAsync(req.Video);

        await _service.Update(serie);
        return Ok(serie);
    }

    [Authorize(Roles = "admin")]
    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        await _service.Delete(id);
        return Ok(new { message = "Serie eliminada correctamente." });
    }

    public record SerieRequest(
        string Titulo,
        string Descripcion,
        int DuracionMinutos,
        int Temporadas,
        DateTime FechaLanzamiento,
        IFormFile Video
    );
}